


const detials =() =>{

    console.log("detilas");

    return(
            <div></div>
    )
}