import classes from './App.module.css';
import Navbar from './components/Navbar';

import Home from './components/routes/Home';

import {BrowserRouter, Routes, Route} from "react-router-dom";

function App() {

  return <div>
      <Navbar />
  </div>
}

export default App;
